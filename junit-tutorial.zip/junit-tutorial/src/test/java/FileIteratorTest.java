import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FileIteratorTest {

    @Test
    void hasNext() {
        try (FileIterator iterator = new FileIterator("src/test/testFiles/test_4.txt")) {
            List<Boolean> expected = Arrays.asList(true, true, true, false);
            List<Boolean> actual = new ArrayList<>();
            while (iterator.hasNext()) {
                actual.add(true);
                iterator.next();
            }
            actual.add(false);
            assertEquals(expected, actual);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try (FileIterator iterator = new FileIterator("src/test/testFiles/test_3.txt")) {
            Boolean expected = false;
            boolean actual;
            actual = iterator.hasNext();
            assertEquals(expected, actual);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void next() {
        try (FileIterator iterator = new FileIterator("src/test/testFiles/test_1.txt")) {
            List<String> expected = Arrays.asList("Первая строка", "И вторая");
            List<String> actual = new ArrayList<>();
            while (iterator.hasNext()) {
                actual.add(iterator.next());
            }
            assertEquals(expected, actual);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try (FileIterator iterator = new FileIterator("src/test/testFiles/test_2.txt")) {
            String expected = "Здесь только одна строка, а в 3 файле их нет";
            String actual;
            actual = iterator.next();
            assertFalse(iterator.hasNext());
            assertEquals(expected, actual);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}