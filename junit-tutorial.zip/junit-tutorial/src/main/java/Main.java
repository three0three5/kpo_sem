
public class Main {
    public static void main(String[] args) {
        try (FileIterator iterator = new FileIterator("src/main/java/test.txt")) {
            while (iterator.hasNext()) {
                System.out.println(iterator.next());
            }
            //System.out.println(iterator.next());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}