package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server implements Runnable {
    private final ServerSocket socket;
    public Server(ServerSocket serverSocket) {
        this.socket = serverSocket;
    }
    public void run() {
        System.out.println("Сервер" + socket.getLocalPort() + " запущен");
        try {
            while (!socket.isClosed()) {
                Socket clientSocket = socket.accept();
                System.out.println("Присоединился новый клиент");
                (new Thread(new ClientHandler(clientSocket))).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
