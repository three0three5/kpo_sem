package server;

import java.io.IOException;
import java.net.ServerSocket;

public class ServerApp {
    public static void main(String[] args) {
        try (ServerSocket firstSocket = new ServerSocket(3333)) {
            new Server(firstSocket).run();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
