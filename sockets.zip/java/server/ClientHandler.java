package server;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ClientHandler implements Runnable {
    private static final List<ClientHandler> clients = new ArrayList<>();
    private final Socket socket;
    private final BufferedReader reader;
    private final BufferedWriter writer;
    private final String name;
    private final int age;
    public ClientHandler(Socket socket) throws IOException {
        this.socket = socket;
        this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        name = reader.readLine();
        age = Integer.parseInt(reader.readLine());
        clients.add(this);
    }

    @Override
    public void run() {
        try {
            while (socket.isConnected()) {
                String message = reader.readLine();
                sendMessage(message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                closeEverything();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void sendMessage(String message) throws IOException {
        if (message == null) {
            return;
        }
        for (var client : clients) {
            if (client.name.equals(this.name) || (client.age >= 18) != (this.age >= 18)) {
                continue;
            }
            client.writer.write(message);
            client.writer.newLine();
            client.writer.flush();
        }
    }

    private void closeEverything() throws IOException {
        sendMessage("Пользователь " + this.name + " покинул чат");
        this.reader.close();
        this.writer.close();
        this.socket.close();
    }
}
