package client;

import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class ClientApp {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите возраст: ");
        int age = sc.nextInt();
        System.out.print("Введите имя: ");
        sc.nextLine();
        String name = sc.nextLine();
        Client client = new Client(age, name, (new Socket("localhost", 3333)));
        client.sendMessages();
        client.listenMessages();
    }
}
