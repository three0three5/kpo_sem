package client;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    private final String name;
    private final Socket socket;
    private final BufferedReader reader;
    private final BufferedWriter writer;
    private final Scanner sc = new Scanner(System.in);
    public Client(int age, String name, Socket socket) throws IOException {
        this.name = name;
        this.socket = socket;
        this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        writer.write(name);
        writer.newLine();
        writer.flush();
        writer.write(Integer.toString(age));
        writer.newLine();
        writer.flush();
    }

    public void listenMessages() {
        while (socket.isConnected()) {
            try {
                String message = reader.readLine();
                System.out.println(message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void sendMessages() {
        (new Thread(() -> {
            try {
                while (socket.isConnected()) {
                    String message = sc.nextLine();
                    writer.write(name + ": " + message);
                    writer.newLine();
                    writer.flush();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        })).start();
    }
}
