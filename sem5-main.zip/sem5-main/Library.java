import java.util.HashMap;
import java.util.HashSet;

public class Library {
    private final HashMap<Book, Integer> booksAndQuantity = new HashMap<>();
    private final HashMap<String, HashSet<Book>> booksWithSimilarNames = new HashMap<>();
    private final HashMap<Book, Integer> booksThatYouTook = new HashMap<>();
    {
        this.putBook("Вредные советы",
                "Григорий Остер",
                1990);
        for (int i = 0; i < 5; ++i) {
            this.putBook("Как приручить жабу",
                    "Грибов Шил",
                    1990);
        }
        this.putBook("ЦыДваКреста за 60 секунд", "Олаф Страусжив", 0);
    }
    public HashMap<Book, Integer> getAllBooks() {
        return booksAndQuantity;
    }
    public HashMap<Book, Integer> getMyBooks() {
        return booksThatYouTook;
    }
    public boolean containsBook(String name, String authors, int year) {
        if (authors == null && year == 0) {
            return booksWithSimilarNames.containsKey(name);
        }
        return booksAndQuantity.containsKey(new Book(name, authors, year));
    }
    public HashSet<Book> getBook(String name) {
        return booksWithSimilarNames.get(name);
    }
    public Book getBook(String name, String authors, int year) {
        if (!containsBook(name, authors, year)) {
            return null;
        }
        int quantityInLibrary = booksAndQuantity.get(new Book(name, authors, year));
        if (quantityInLibrary == 1) {
            booksAndQuantity.remove(new Book(name, authors, year));
            booksWithSimilarNames.remove(name);
        } else {
            booksAndQuantity.put(new Book(name, authors, year), --quantityInLibrary);
            HashSet<Book> booksWithThisName = booksWithSimilarNames.get(name);
            booksWithThisName.remove(new Book(name, authors, year));
        }
        int yourQuantity = 0;
        if (booksThatYouTook.containsKey(new Book(name, authors, year))) {
            yourQuantity = booksThatYouTook.get(new Book(name, authors, year));
        }
        booksThatYouTook.put(new Book(name, authors, year), ++yourQuantity);
        return new Book(name, authors, year);
    }
    public boolean putBook(String name, String authors, int year) {
        boolean bookIsNew = true;
        int quantity = 0;
        if (containsBook(name, authors, year)) {
            bookIsNew = false;
            quantity = booksAndQuantity.get(new Book(name, authors, year));
        }
        booksAndQuantity.put(new Book(name, authors, year), ++quantity);
        HashSet<Book> booksWithThisName =
                booksWithSimilarNames.computeIfAbsent(name, k -> new HashSet<>());
        booksWithThisName.add(new Book(name, authors, year));
        if (booksThatYouTook.containsKey(new Book(name, authors, year))) {
            quantity = booksThatYouTook.get(new Book(name, authors, year));
            if (quantity == 1) {
                booksThatYouTook.remove(new Book(name, authors, year));
            } else {
                booksThatYouTook.put(new Book(name, authors, year), --quantity);
            }
        }
        return bookIsNew;
    }
}
