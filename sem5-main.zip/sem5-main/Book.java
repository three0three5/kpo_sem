import java.time.LocalDate;
import java.util.Objects;

public class Book {
    public String name;
    public String authors;
    public Integer year;

    /**
     * Конструктор для новой книги
     * @param name Обязательный параметр
     * @param authors Обязательный параметр
     * @param year Необязательный параметр. Может иметь значение null
     */
    Book(String name, String authors, int year) {
        this.name = name;
        this.authors = authors;
        this.year = year;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Book)) {
            return false;
        }
        if (!Objects.equals(name, ((Book) obj).name)) return false;
        if (!Objects.equals(authors, ((Book) obj).authors)) return false;
        return Objects.equals(year, ((Book) obj).year);
    }
    @Override
    public int hashCode() {
        int PRIME = 305175781;
        int result = name.hashCode() % PRIME + authors.hashCode() % PRIME;
        if (year != null) {
            result %= PRIME;
            result += year.hashCode() % PRIME;
        }
        return result;
    }
}
