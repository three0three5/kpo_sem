import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class Main {
    private static final Scanner in = new Scanner(System.in);
    private static final Library lib = new Library();
    private static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch(NumberFormatException e){
            return false;
        }
    }
    private static void printNamesOfBooks(HashSet<Book> books) {
        System.out.println("Книги с таким названием: ");
        if (books == null || books.isEmpty()) {
            System.out.println("Книг нет!");
            return;
        }
        for (Book book : books) {
            System.out.print("Название: " + book.name + ", Автор: " + book.authors);
            if (book.year != 0) {
                System.out.print(", Год выпуска: " + book.year);
            }
            System.out.println();
        }
    }
    private static void getSomeBooks(String str) {
        str = str.substring(5);
        String[] parts = str.split(", ");
        if (parts.length == 1) {
            HashSet<Book> names = lib.getBook(parts[0]);
            printNamesOfBooks(names);
            return;
        }
        String name = parts[0], authors = parts[1];
        int year = 0;
        if (parts.length == 3 && isNumeric(parts[2])) {
            year = Integer.parseInt(parts[2]);
        }
        Book book = lib.getBook(name, authors, year);
        if (book == null) {
            System.out.println("Такой книги нет");
            return;
        }
        System.out.println("Книга взята");
    }
    private static void putTheBook(String str) {
        str = str.substring(5);
        String[] parts = str.split(", ");
        if (parts.length < 2) {
            return;
        }
        String name = parts[0];
        String authors = parts[1];
        int year = 0;
        if (parts.length == 3 && isNumeric(parts[2])) {
            year = Integer.parseInt(parts[2]);
        }
        lib.putBook(name, authors, year);
    }
    private static void printSomeBooks(HashMap<Book, Integer> books) {
        if (books == null || books.isEmpty()) {
            System.out.println("Книг нет!");
            return;
        }
        for (Book key : books.keySet()) {
            System.out.print("Название: " + key.name + ", Автор: " + key.authors);
            if (key.year != 0) {
                System.out.print(", Год выпуска: " + key.year);
            }
            System.out.println(", Количество: " + books.get(key));
        }
    }
    private static void printAllBooks() {
        printSomeBooks(lib.getAllBooks());
    }
    private static void printMyBooks() {
        printSomeBooks(lib.getMyBooks());
    }
    public static void main(String[] args) {
        System.out.println(Constants.GREETINGS);
        String inputString = in.nextLine();
        while (!"/q".equals(inputString)) {
            if ("/list".equals(inputString)) {
                printMyBooks();
            } else if (inputString.startsWith("/get ")) {
                getSomeBooks(inputString);
            } else if (inputString.startsWith("/put ")) {
                putTheBook(inputString);
            } else if ("/all".equals(inputString)) {
                printAllBooks();
            } else {
                System.out.println("Команда некорректна!");
            }
            inputString = in.nextLine();
        }
    }
}
